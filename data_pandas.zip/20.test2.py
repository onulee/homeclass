import pandas as pd
import sqlite3 as sq3

con = sq3.connect('./pddata.db')

cursor = con.cursor()
query = 'CREATE TABLE stock (Date date, Open integer, Close integer)'

cursor.execute(query)

q = con.execute
q('SELECT * FROM sqlite_master').fetchall()

